#ifndef MAINDIALOG_H
#define MAINDIALOG_H

class CMainDialog : public CDialog
{
public:
	CMainDialog(UINT resID);
	virtual ~CMainDialog();

protected:
	virtual void OnDestroy();
	virtual BOOL OnInitDialog();
	virtual INT_PTR DialogProc(UINT msg, WPARAM wparam, LPARAM lparam);
	virtual BOOL OnCommand(WPARAM wparam, LPARAM lparam);
private:
};

#endif //MYDIALOG_H
