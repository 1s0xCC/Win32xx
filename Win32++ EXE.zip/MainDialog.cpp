#include "stdafx.h"
#include "MainDialog.h"
#include "resource.h"

CMainDialog::CMainDialog(UINT resID) : CDialog(resID)
{
}

CMainDialog::~CMainDialog()
{
}

void CMainDialog::OnDestroy()
{
	::PostQuitMessage(0);
}

INT_PTR CMainDialog::DialogProc(UINT msg, WPARAM wparam, LPARAM lparam)
{
	return DialogProcDefault(msg, wparam, lparam);
}

BOOL CMainDialog::OnCommand(WPARAM wparam, LPARAM lparam)
{
	UNREFERENCED_PARAMETER(lparam);

	UINT id = LOWORD(wparam);
	switch (id)
	{
	case IDOK:
	{
		CDialog::OnOK();
	}
	case IDCANCEL:
	{
		CDialog::OnCancel();
	}
	}
	return FALSE;
}
BOOL CMainDialog::OnInitDialog()
{
	// Set the Icon
	//SetIconLarge(IDW_MAIN);
	//SetIconSmall(IDW_MAIN);

	return TRUE;
}