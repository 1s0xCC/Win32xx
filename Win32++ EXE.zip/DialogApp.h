///////////////////////////////////////
// DialogApp.h

#ifndef DIALOGAPP_H
#define DIALOGAPP_H

#include "MainDialog.h"

class CDialogApp : public CWinApp
{
public:
	CDialogApp();
	virtual ~CDialogApp();
	virtual BOOL InitInstance();
	CMainDialog& GetDialog() { return m_MainDialog; }

private:
	CMainDialog m_MainDialog;
};

inline CDialogApp& GetDialogApp() { return static_cast<CDialogApp&>(GetApp()); }

#endif