﻿// Win32++.cpp : 定义 DLL 应用程序的导出函数。
//

#include "stdafx.h"
#include "Win32++.h"
#include "DialogApp.h"

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	try
	{
		CDialogApp App;
		return App.Run();
	}
	catch (const CException &e)
	{
		MessageBox(NULL, e.GetText(), AtoT(e.what()), MB_ICONERROR);
		return -1;
	}
}