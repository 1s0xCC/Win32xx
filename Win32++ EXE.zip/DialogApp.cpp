#include "stdafx.h"
#include "DialogApp.h"
#include "resource.h"

CDialogApp::CDialogApp() : m_MainDialog(IDD_DIALOG1)
{
}

/*��ʼ��*/
BOOL CDialogApp::InitInstance()
{
	m_MainDialog.DoModal();

	return TRUE;
}

CDialogApp::~CDialogApp()
{
}